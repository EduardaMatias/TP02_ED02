﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP02_ED2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.ReadKey();
        }
    }
}